package cs3500.music.view.GuiView;

import java.awt.*;
import java.awt.event.KeyListener;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;

import javax.swing.*;

import cs3500.music.model.CompositionModel;

/**
 * Main GUI Frame that displays the GuiPanelImpl sub-view
 */
public class GuiViewImpl extends JFrame implements GUIView {
  private CompositionModel comp;
  private GuiPanelImpl musicSheet;

  private final int windowWidth = 11 * 4;

  public GuiViewImpl() throws HeadlessException {
    this.setTitle("Music Editor");

    this.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
    this.setLocation(50, 50);
    this.setLayout(new BorderLayout());
    this.setResizable(true);

    this.setResizable(false);
  }

  public void setComp(CompositionModel comp) {
    this.comp = comp;
    this.musicSheet = new GuiPanelImpl(0, windowWidth, this.comp);
  }

  //Added by Ollie
  public GuiPanelImpl getMusicSheet(){
    return this.musicSheet;
  }

  public void setKeyHandler(KeyListener handler) {
    this.addKeyListener(handler);
  }

  public void setMouseHandler(MouseListener handler) {
    if (this.musicSheet != null) {
      this.musicSheet.addMouseListener(handler);
      this.musicSheet.addMouseMotionListener((MouseMotionListener) handler);
    }
  }

  public GUIView getGuiView() {
    return this;
  }

  public CompositionModel getComp() {
    return this.comp;
  }

  public int getStartBeat() {
    return musicSheet.getStartBeat();
  }

  public int getEndBeat() {
    return musicSheet.getEndBeat();
  }

  //(red line)
  public void playNotesAtBeat(int currentBeat) {
    if (currentBeat <= musicSheet.getEndBeat() && currentBeat >= musicSheet.getStartBeat()) {
      musicSheet.setLineBeat(currentBeat % windowWidth);
    } else if (currentBeat < musicSheet.getStartBeat()) {
      int newStart = Math.abs(musicSheet.getStartBeat() - windowWidth);
      int newEnd = newStart + windowWidth;
      musicSheet.setStartBeat(newStart);
      musicSheet.setEndBeat(newEnd);
    } else if ((currentBeat + windowWidth) < this.comp.songLength()) {
      int newStart = musicSheet.getEndBeat();
      int newEnd = newStart + windowWidth;
      musicSheet.setStartBeat(newStart);
      musicSheet.setEndBeat(newEnd);
    } else {
      int newStart = musicSheet.getEndBeat();
      musicSheet.setEndBeat(this.comp.songLength());
      musicSheet.setStartBeat(newStart);
      musicSheet.setLineBeat(0);
    }

    this.repaint();
  }

  public void render() {
    final JScrollPane scrollPane = new JScrollPane(musicSheet,
            JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED,
            JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
    this.add(scrollPane, BorderLayout.CENTER);

    this.setVisible(true);
    this.setSize(1000, 750);
  }

  public void Repaint() {
    this.repaint();
  }
}
